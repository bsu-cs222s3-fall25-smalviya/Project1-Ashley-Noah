Project 1 CS222

Ashley Napier

Noah Tutt


This project allows users to retrieve information about a Wikipedia article. The system asks the user for the name of the wikipedia article then displays the 15 most recent changes to the page.

How to Run:

    1. Locate the WikipediaRevisonReader class.
    2. Run the file.
    3. Enter the title of the Wiki article in the console.
        Enter "Zappa"

GUI is currently unavailable